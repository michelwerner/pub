﻿cls
$script:steps = "50" #([System.Management.Automation.PsParser]::Tokenize((gc "$PSScriptRoot\$($MyInvocation.MyCommand.Name)"), [ref]$null) | where { $_.Type -eq 'Command' -and $_.Content -eq 'Write-Progress' }).Count
#write-host $script:steps
$stepCounter = 0
$error = 0

$outputdc = @()
$outputsrv = @()
$outputdns = @()
$outputos = @()
$outputfsmo = @()
$outputfor= @()
$outputdnszone = @()
$outputdhcp = @()

$stepCounter++
Write-Progress -Activity "Erstelle Informationen ..." -Status "Processing $($stepCounter) of $($script:steps) | Fülle allgemeine Variablen"
#$ForestObj = (Get-ADForest).Domains
#$AllDcs = $Domains | % { Get-ADDomainController -Filter * }
try
{
$AllDcs = (Get-ADForest).Domains | % { Get-ADDomainController -Discover -DomainName  $_ } | % { Get-ADDomainController -server $_.Name -filter * } #| Select Name, Domain, Forest, IPv4Address, Site, OperationMasterRoles
}
Catch
{
	$error++
}

#foreach($Domain in $ForestObj) {    
#	$AllDcs = Get-ADDomainController -Filter * #-Server $Domain | select Domain,Hostname,Ipv4address,isglobalcatalog,site,forest,operatingsystem
#}

foreach ($ComputerName in ($AllDcs.Hostname)) {
##This section queries and collects the relevant information into variables
			
			$dcinfo = Get-ADDomainController -server $ComputerName | select-object -property *
			$netinfo = Get-WmiObject Win32_NetworkAdapterConfiguration -ComputerName $ComputerName  | ? {$_.IPEnabled}
			$osinfo = Get-CimInstance -ClassName win32_operatingsystem -ComputerName $ComputerName  | Select-Object -Property *
			
			if ($osinfo.version -like "*6.3*") {
				$osversion = "2012 R2"
			}
			elseif ($osinfo.version -like "*6.2*") {
				$osversion = "2012"
			}
			elseif ($osinfo.version -like "*10.0*") {
				$osversion = "2019"
			}
			elseif ($osinfo.version -like "*6.1*") {
				$osversion = "2008 R2"
			}
			elseif ($osinfo.version -like "*6.0*") {
				$osversion = "2008"
			}
			
			if ($osinfo.caption -like "*Standard*") {
				$osedition = "Standard"
			}
			if ($osinfo.caption -like "*Enterprise*") {
				$osedition = "Enterprise"
			}
			if ($osinfo.caption -like "*Datacenter*") {
				$osedition = "Datacenter"
			}
			$OpsMasterRole = $dcinfo.OperationMasterRoles -join ','
			$DefaultGateway = $netinfo.DefaultIPGateway -join ','
			$DNSServers = $netinfo.DNSServerSearchOrder -join ','
			$IPAddinfo = ($netinfo | Where-Object{$_.ipaddress -notlike $null, "192", "169"}).IPaddress | Select-Object -First 1			           
					   
            $basicinfo = Get-WmiObject Win32_ComputerSystem -ComputerName $ComputerName -ErrorAction STOP | Select-Object Name,DnsHostName,Domain
            $memory = Get-WmiObject -Class Win32_PhysicalMemory -ComputerName $ComputerName |Measure-Object -Property capacity -Sum
            $hardwareinfo = Get-WmiObject -Class Win32_ComputerSystem -ComputerName $ComputerName -Property Manufacturer, Model
            $processor = Get-WmiObject –class Win32_processor -ComputerName $ComputerName | Select-Object systemname,Name,DeviceID,NumberOfCores,NumberOfLogicalProcessors, Addresswidth
            $serial = Get-WmiObject -Class Win32_Bios -ComputerName $ComputerName 
			$TotalAvailMemory = ([math]::round(($memory.Sum / 1GB),2))
			$Cim = New-CimSession -computername $computername
			$HDD = Get-Volume -CimSession $cim | ? {($_.DriveLetter -eq "C")} | select-object Driveletter, Size, Sizeremaining
			$HDD.Size = [math]::round($HDD.Size /1Gb, 0)
			$HDD.SizeRemaining = [math]::round($HDD.SizeRemaining /1Gb, 0)
			
			$forestInfo = Get-ADForest
			$AllDomains = (Get-ADForest).Domains
			$domainInfo = Get-ADDomain
			$PDCEmulator = (Get-ADDomain).PDCEmulator
			$DNSRoot = $domainInfo.dnsroot
			$ADsiteLinks = Get-ADReplicationSiteLink -Filter *
			$DomainMode = ($DNSRoot | foreach { Get-ADDomain -Identity $_ } | Select-Object -ExpandProperty DomainMode) -join ' ,'
			$NetBIOSName = $domainInfo.netBIOSName

$stepCounter++
#write-host $stepCounter
Write-Progress -Activity "Erstelle Informationen ..." -Status "Processing $($stepCounter) of $($script:steps) | Region Server Info $computername"		
# Server Region
			$objsrv = new-object -type psobject #-Property @{
            $objsrv | Add-Member -MemberType NoteProperty -Name Servername -Value $basicinfo.DnsHostName
			$objsrv | Add-Member -MemberType NoteProperty -Name "Memory (GB)" -Value ("{0:N2}" -f $TotalAvailMemory)
            $objsrv | Add-Member -MemberType NoteProperty -Name CPU -Value $processor.NumberOfLogicalProcessors
			$objsrv | Add-Member -MemberType NoteProperty -Name Manufacturer -Value $hardwareinfo.manufacturer
			$objsrv | Add-Member -MemberType NoteProperty -Name Drive -Value $HDD.Driveletter
			$objsrv | Add-Member -MemberType NoteProperty -Name Size -Value $HDD.size
			$objsrv | Add-Member -MemberType NoteProperty -Name Free -Value $HDD.SizeRemaining
			#$objsrv			 
			$outputsrv += $objsrv
#$stepCounter - 6

$stepCounter++
#write-host $stepCounter
Write-Progress -Activity "Erstelle Informationen ..." -Status "Processing $($stepCounter) of $($script:steps) | Region DNS Settings $computername"
# DNS Region
			$objdns = new-object -type psobject #-Property @{
            $objdns | Add-Member -MemberType NoteProperty -Name Servername -Value $basicinfo.DnsHostName
			$objdns | Add-Member -MemberType NoteProperty -Name IP -Value $ipaddinfo
			$objdns | Add-Member -MemberType NoteProperty -Name SN -Value $netinfo.IPSubnet[0]
			$objdns | Add-Member -MemberType NoteProperty -Name GW -Value $DefaultGateway
			$objdns | Add-Member -MemberType NoteProperty -Name "DNS Server" -Value $DNSServers
			$objdns | Add-Member -MemberType NoteProperty -Name "WINS 1" -Value $netinfo.WINSPrimaryServer
			$objdns | Add-Member -MemberType NoteProperty -Name "WINS 2" -Value $netinfo.WINSSecondaryserver
			$objdns | Add-Member -MemberType NoteProperty -Name "DHCP Enabled" -Value $netinfo.DHCPEnabled
			#$objdns			 
			$outputdns += $objdns
#$stepCounter - 6
			
$stepCounter++
Write-Progress -Activity "Erstelle Informationen ..." -Status "Processing $($stepCounter) of $($script:steps) | Region OS $computername"	
# OS Region
			$objos = new-object -type psobject #-Property @{
            $objos | Add-Member -MemberType NoteProperty -Name Servername -Value $osinfo.PSComputerName
			$objos | Add-Member -MemberType NoteProperty -Name Sprache -Value $osinfo.OSLanguage
			$objos | Add-Member -MemberType NoteProperty -Name Version -Value $osversion
			$objos | Add-Member -MemberType NoteProperty -Name Edition -Value $osedition
			$objos | Add-Member -MemberType NoteProperty -Name Uptime -Value $osinfo.LastBootuptime
			#$objos			 
			$outputos += $objos
#$stepCounter - 6
			
$stepCounter++
Write-Progress -Activity "Erstelle Informationen ..." -Status "Processing $($stepCounter) of $($script:steps) | Region FSMO Roles $computername"				
# DC Server Region
			$objfsmo = new-object -type psobject
			$objfsmo | Add-Member -MemberType NoteProperty -Name ServerName -Value $basicinfo.DnsHostName			
			$objfsmo | Add-Member -MemberType NoteProperty -Name FSMO -Value $opsMasterRole
			#$objfsmo
			$outputfsmo += $objfsmo

$stepCounter++
Write-Progress -Activity "Erstelle Informationen ..." -Status "Processing $($stepCounter) of $($script:steps) | Region Domain Controller $computername"					
# DC Server Region
			$objdc = new-object -type psobject
			$objdc | Add-Member -MemberType NoteProperty -Name ServerName -Value $basicinfo.DnsHostName
			$objdc | Add-Member -MemberType NoteProperty -Name Domain -Value $dcinfo.domain
			$objdc | Add-Member -MemberType NoteProperty -Name Forest -Value $dcinfo.forest
			$objdc | Add-Member -MemberType NoteProperty -Name Site -Value $dcinfo.Site
			$objdc | Add-Member -MemberType NoteProperty -Name "GC" -Value $dcinfo.IsGlobalCatalog
			$objdc | Add-Member -MemberType NoteProperty -Name RODC -Value $dcinfo.IsReadOnly
			#$objdc
			$outputdc += $objdc
#$stepCounter - 6
			
$stepCounter++
Write-Progress -Activity "Erstelle Informationen ..." -Status "Processing $($stepCounter) of $($script:steps) | Region DNS Server $computername"	
#Region DNS Zone Info
$PrimaryZones =  (Get-DnsServerZone -ComputerName $PDCEmulator | Where-Object {$_.IsReverseLookupZone -eq $False} | Select-Object -ExpandProperty ZoneName) -join ' ,'
$NSRecords =  (Resolve-DnsName -Name $DNSRoot -type ns | Where-Object {$_.QueryType -eq 'NS'} | Select-Object -ExpandProperty Server) -join ' ,'
$MXRecords =  (Resolve-DnsName -Name $DNSRoot -type MX | Where-Object {$_.QueryType -eq 'MX'} | Select-Object -ExpandProperty Exchange) -join ' ,'
$DNSForwarders = (Get-DnsServerForwarder -ComputerName $PDCEmulator | Select-Object -ExpandProperty IPAddress) -join ' ,'
$DNSScavenging = (Get-DnsServerScavenging -ComputerName $PDCEmulator).scavengingState
$DNSAging = (Get-DnsServerZoneAging -Name $DNSRoot -ComputerName $PDCEmulator).AgingEnabled
 
	$objdnszone  = New-Object -TypeName PSObject
	$objdnszone | Add-Member -MemberType NoteProperty -Name "Primary DNS Zone" -Value $PrimaryZones
	$objdnszone | Add-Member -MemberType NoteProperty -Name "NS Records" -Value $NSRecords
	$objdnszone | Add-Member -MemberType NoteProperty -Name "MX Records" -Value $MXRecords
	$objdnszone | Add-Member -MemberType NoteProperty -Name "DNS Forwarders" -Value $DNSForwarders
	$outputdnszone += $objdnszone
#End Region DNS Zone Info
#$stepCounter - 6

$stepCounter++
Write-Progress -Activity "Erstelle Informationen ..." -Status "Processing $($stepCounter) of $($script:steps) | Region NTP Settings $computername"					
#NTP Region
	w32tm /monitor | set-content .\data\"ntp $($basicinfo.DnsHostName).txt"

$stepCounter++
Write-Progress -Activity "Erstelle Informationen ..." -Status "Processing $($stepCounter) of $($script:steps) | Region DHCP Server $computername"		
#Region DHCP Info			
<# $DHCP = Get-WindowsFeature -name DHCP | Where-Object {$_.Installed -eq $True}
 
If($DHCP){
	$DHCPServers =  Get-DhcpServerInDC
 
  $Objdhcp  = New-Object -TypeName PSObject
  $Objdhcp | Add-Member -MemberType NoteProperty -Name Name -Value $DHCPServers.DNSName
  $Objdhcp | Add-Member -MemberType NoteProperty -Name IPAddress -Value $DHCPServers.IPAddress
  $outputdhcp = $Objdhcp
} Else {
  $DHCPServers =  'No DHCP Found'
  $Objdhcp  = New-Object -TypeName PSObject
  $Objdhcp | Add-Member -MemberType NoteProperty -Name "DHCP Server" -Value $DHCPServers
  $outputdhcp = $Objdhcp
} #>
#End Region DHCP Info
#$stepCounter - 6
}

$stepCounter++
Write-Progress -Activity "Erstelle Informationen ..." -Status "Processing $($stepCounter) of $($script:steps) | Region Admin Groups"
#Region Admin Groups
$Groups = Get-ADGroup -LDAPFilter "(admincount=1)" | select-object Name, GroupCategory, GroupScope

	$outputadadmingroup = @()
foreach ($group in $Groups) {

	$objadadmingroup  = New-Object -TypeName PSObject
	$objadadmingroup | Add-Member -MemberType NoteProperty -Name "Group Name" -Value $group.name
	$objadadmingroup | Add-Member -MemberType NoteProperty -Name "Members" -Value (Get-ADGroupMember -Identity $group.name).count
	$objadadmingroup | Add-Member -MemberType NoteProperty -Name "Category" -Value $group.groupcategory
	$objadadmingroup | Add-Member -MemberType NoteProperty -Name "Scope" -Value $group.groupscope
	$outputadadmingroup += $objadadmingroup
	$outputadadmingroup | Export-CSV .\data\"$($group.name).csv" -notypeinformation
}
#End Region Admin Groups

$stepCounter++
Write-Progress -Activity "Erstelle Informationen ..." -Status "Processing $($stepCounter) of $($script:steps) | Region Forest/Domain Info"
#region Forest Info
  
	$RootDomain = $forestInfo.RootDomain
	$ForestMode = ($forestInfo.ForestMode).toString()
	$Domains = ($forestInfo | Select-Object -ExpandProperty Domains) -join ' ,'
	$ADRecycleBIN = Get-ADOptionalFeature -filter {Name -eq 'Recycle Bin Feature'} | Select-Object -ExpandProperty EnabledScopes
 
	If (!$ADRecycleBIN){
		$ADRecycleBIN = 'Disabled'
	} else {
		$ADRecycleBIN = 'Enabled'
	}
 
# Forest Information Output Object 
  $objforest  = New-Object -TypeName PSObject
  $objforest | Add-Member -MemberType NoteProperty -Name ForestRootDomain -Value $RootDomain
  $objforest | Add-Member -MemberType NoteProperty -Name ForestFunctionalLevel -Value $ForestMode.Replace("Forest","")
  $objforest | Add-Member -MemberType NoteProperty -Name DomainFunctionalLevel -Value ($DomainMode).Replace("Domain","")
  $objforest | Add-Member -MemberType NoteProperty -Name ForestDomains -Value $Domains
  $objforest | Add-Member -MemberType NoteProperty -Name NetBIOS_Name -Value $NetBIOSName
  $objforest | Add-Member -MemberType NoteProperty -Name ADRecycleBIN -Value $ADRecycleBIN
  $outputfor += $objforest
#endregion

$outputsrv | Export-CSV .\data\"Server Information.csv" -notypeinformation
$outputdns | Export-CSV .\data\"Netzwerk Konfiguration.csv" -notypeinformation
$outputos  | Export-CSV .\data\"OS Information.csv" -notypeinformation
$outputdc  | Export-CSV .\data\"AD Server.csv" -notypeinformation
$outputfsmo  | Export-CSV .\data\"FSMO.csv" -notypeinformation
$outputfor	| Export-CSV .\data\"Forest.csv" -notypeinformation
$outputdnszone | Export-CSV .\data\"DNSZones.csv" -notypeinformation
$outputdhcp | Export-CSV .\data\"DHCP.csv" -notypeinformation
$outputadadmingroup | Export-CSV .\data\"Admin Groups.csv" -notypeinformation
($outputadadmingroup).count | set-content .\data\"Count Admin Groups.txt"

cls
$error = ($script:steps - $error)
Write-Host "|-------------------|"
Write-Host "|Script finished!   |"
Write-Host "|$error of $script:steps successful|"
Write-Host "|-------------------|"

			#Installed on
			#Pending reboot
##This command will take the information collected above and export it to a CSV within the C:\temp folder
#$output | Select-Object Servername,ADDomain,IPAddress,PageFile, PageFileLocation, "Memory (GB)", Manufacturer, CPU | Export-CSV c:\temp\OSinfo.csv
#$output | Export-CSV c:\temp\OSinfo.csv -notypeinformation
    

