Set-StrictMode   -Version 2.0

$cReporttitle = "Avilon ADS Report"

#region Functions

Function  Remove-MSWordDocumentSession {
	param(
		[Parameter(Position=0,Mandatory = $true)] 
		[String]$ParamWordfileName
	)
	Try {
		$ExitCode = 0
		$Message = ""
		#$wdFormatDocument =  0
		$saveFormat = [Microsoft.Office.Interop.Word.WdSaveFormat]::wdFormatXMLDocument
		$Script:doc.SaveAs([ref]$ParamWordfileName,[ref]$saveFormat) 
		$script:doc.Close()
		$script:word.Quit()
	
	} catch {
		$ExitCode = 1
		$Message = $_.exception 
	} Finally {
		$Output = New-Object -Type PSObject -Prop @{  'ExitCode' = $ExitCode
		  											  'Message'= $Message
													}
		Write-Output $Output
	
	}
}

Function  Add-MSWordText {

	[CmdletBinding()]
    param(

	[Parameter(Position=0,mandatory = $true)] 
		[String]$text,
	[Parameter(Position=1)] 
    	[Microsoft.Office.Interop.Word.WdColor]$Color,
	[Parameter(Position=2)] 	
        [String]$FontName,
	[Parameter(Position=3)] 	
        [Int]$Size,
	[Parameter(Position=4)] 	
        [Switch]$Bold,
	[Parameter(Position=5)] 	
        [Switch]$Italic
	)

	try {
		$ExitCode = 0
		$Message = ""
		$FontPropOldName = $Script:doc.Application.Selection.font.name
		$FontPropOldColor = $Script:doc.Application.Selection.font.Color
		$FontPropOldSize = $Script:doc.Application.Selection.font.Size
		$FontPropOldIsBold = $Script:doc.Application.Selection.font.BoldBi
		$FontPropOldIsItalic= $Script:doc.Application.Selection.font.Italic
		
		if ($PSBoundParameters.ContainsKey('Color')) {
			$Script:doc.Application.Selection.font.Color = $color
		}
		
		if ($PSBoundParameters.ContainsKey('FontName')) {
			$Script:doc.Application.Selection.font.name = $FontName
		}
		
		if ($PSBoundParameters.ContainsKey('Size')) {
			$Script:doc.Application.Selection.font.size = $Size
		}
		
		if ($PSBoundParameters.ContainsKey('Bold')) {
			$Script:doc.Application.Selection.font.Bold = if ($Bold) { 1 } else {0}
		}
		
		if ($PSBoundParameters.ContainsKey('Italic')) {
			$Script:doc.Application.Selection.font.Italic = if ($Italic) { 1 } else {0}
		}
		
		$Script:doc.Application.Selection.TypeText("$($Text)")	
		
		
		$Script:doc.Application.Selection.font.name = $FontPropOldName
		$Script:doc.Application.Selection.font.Color = $FontPropOldColor
		$Script:doc.Application.Selection.font.Size = $FontPropOldSize
		$Script:doc.Application.Selection.font.Bold = $FontPropOldIsBold
		$Script:doc.Application.Selection.font.Italic = $FontPropOldIsItalic

		$Script:doc.Application.Selection.TypeParagraph() 
	} catch {
		Write-Warning "Could not Add the Text :$($_.exception.message)"
	}

		
}

Function Add-MSWordTOC {
	try {
	
		$useHeadingStyles = $true
		$upperHeadingLevel = 1                            # <-- Heading1 or Title
		$lowerHeadingLevel = 2                         # <-- Heading2 or Subtitle
		$useFields = $false
		$tableID = $null
		$rightAlignPageNumbers = $true
		$includePageNumbers = $true
		# to include any other style set in the document add them here
		$addedStyles = $null
		$useHyperlinks = $true
		$hidePageNumbersInWeb = $true
		$useOutlineLevels = $true
		$Selection = $Script:Word.Selection
		$range = $Selection.Range
		$toc = $Script:Doc.TablesOfContents.Add(	$range, $useHeadingStyles,
													   $upperHeadingLevel, $lowerHeadingLevel, $useFields, $tableID,
													   $rightAlignPageNumbers, $includePageNumbers, $addedStyles,
													   $useHyperlinks, $hidePageNumbersInWeb, $useOutlineLevels
									  				)
		$Script:Word.Selection.EndKey(6) > $Null
		$Selection.TypeParagraph()
	} catch {
		Write-Warning "Could not Add The TOC Error:$($_.exception.message)"
	}
}

Function Update-MSWordTOC {
	try {
		$Script:Doc.Fields | 
		ForEach-Object{ 
			$_.Update() >> $null
		}
	} catch {
		Write-Warning "Could not Update The TOC Error:$($_.exception.message)"
	}
}

Function  Add-MSWordParagraph {

	[CmdletBinding()]
    param(

	[Parameter(Position=0)] 
		[String]$text,
	[Parameter(Position=1)] 
		[Microsoft.Office.Interop.Word.WdBuiltinStyle]$Style 
	)

	try {
		$Selection = $Script:Word.Selection
		$Selection.Style = $style
		$Selection.TypeText($text)
		$Script:Word.Selection.EndKey(6) > $null
		$Selection.TypeParagraph()
	} catch {
		Write-Warning "Could not Add the Paragraph Error:$($_.exception.message)"
	}	
}

# insert break
Function  Add-MSWordBreak {
    
	try {
		$Selection = $Script:Word.Selection
		$Selection.InsertBreak()
	} catch {
		Write-Warning "Could not Add break Error:$($_.exception.message)"
	}	
}



Function Start-MSWordDocumentSession {
	[CmdletBinding()]
    param(

	[Parameter(Position=0)] 
		[switch]$Visible,


	[Parameter(Position=1)] 
		[ValidateScript({Test-Path $_ })] 
        [string] 
        $TemplatePath 
	)
	$ExitCode = 0
	$Message = ""
	try {
		$script:word = New-Object -ComObject "Word.application" 
		$script:word.visible = $Visible       
        if ($TemplatePath)  {
            $script:doc = $script:word.Documents.Add($TemplatePath)
        } else {  
     
		    $script:doc = $script:word.Documents.Add()  
        }          
		$script:doc.Activate()
	} catch {
		$ExitCode = 1
		$Message = $_.exception 
	} Finally {
		$Output = New-Object -Type PSObject -Prop @{  'ExitCode' = $ExitCode
		  											  'Message'= $Message
													}
		Write-Output $Output
	
	}
}

Function Add-MSWordTable {
	[CmdletBinding()]
    param(

	[Parameter(Position=0, Mandatory=$true)] 
	[psobject]$Object,
	[Parameter(Position=1)] 
	[int]$Size=11	
    )
		
   
	try {
		$TableRange = $script:doc.application.selection.range
		$Columns = @($Object | Get-Member -MemberType Property,NoteProperty).count
		$Rows = @($Object).count +1
			
		if ($rows -eq 1) {
			$Rows = 2
		}	
		$Table = $script:doc.Tables.Add($TableRange, $Rows, $Columns) 
		$Table.AllowAutoFit = $true
		$table.AutoFitBehavior(1)
		$table.Borders.InsideLineStyle = 1
		$table.Borders.OutsideLineStyle = 1
		$xRow = 1
		$XCol = 1
		$PropertyNames = @()
		if ($Object -is [Array]) {
			$HeaderNames = $Object[0].psobject.properties | % {$_.Name}
		} else {
			$HeaderNames = $Object.psobject.properties | % {$_.Name}
		}

		#if ($Size -eq 11 -and $Columns -gt 5) {
		#	$Size = 8
		#}
		for ($c=0; $c -le $Columns -1; $c++) {
		
			$Table.Cell($xRow,$XCol).Range.Font.Bold = $True
			$Table.Cell($xRow,$XCol).Range.Font.Size= [int]$Size
	        $PropertyNames += $HeaderNames[$c]
	        $Table.Cell($xRow,$XCol).Range.Text = $HeaderNames[$c]
			$Xcol++
		}	

		$xRow = 2
		$Object |
		ForEach-Object {
			$XCol = 1
			for ($c=0; $c -le $Columns -1; $c++) {
				$Split = (invoke-expression -Command  "`$_.'$($PropertyNames[$c])'") -split ";"
				$Table.Cell($xRow,$XCol).Range.Font.Size= [int]$size

				switch ($Split[1]) {
					'Red' {$Table.Cell($xRow,$XCol).Range.Shading.BackgroundPatternColor = [Microsoft.Office.Interop.Word.WdColor]::wdColorRed}
					'Yellow' {$Table.Cell($xRow,$XCol).Range.Shading.BackgroundPatternColor = [Microsoft.Office.Interop.Word.WdColor]::wdColorYellow} 
					'Aqua' {$Table.Cell($xRow,$XCol).Range.Shading.BackgroundPatternColor = [Microsoft.Office.Interop.Word.WdColor]::wdColorAqua} 
					'Green' {$Table.Cell($xRow,$XCol).Range.Shading.BackgroundPatternColor = [Microsoft.Office.Interop.Word.WdColor]::wdColorGreen} 
				default {$Table.Cell($xRow,$XCol).Range.Shading.BackgroundPatternColor = [Microsoft.Office.Interop.Word.WdColor]::wdColorAutomatic}

				}

				$Table.Cell($xRow,$XCol).Range.Text = $Split[0]
				#if ($Table.Cell($xRow,$XCol).Range.Text -like "*2012 R2*") {
				#write-verbose $Table.Cell($xRow,$XCol).Range.Text
				#$Table.Cell($xRow,$XCol).Range.InlineShapes.AddPicture("E:\Michel\Avilon\Scripts\org\Best Practice\2012.jpg")
				#}
				$XCol++
			}	
			$xRow++
		}
		#$UserTable.Cell($TableRowPosition,4).Range.InlineShapes.AddPicture("C:\DiscoveryData\images\greencircle.png")
		$selection = $script:doc.application.selection
		[Void]$selection.goto([Microsoft.Office.Interop.Word.WdGoToItem]::wdGoToBookmark,$null,$null,"\EndOfDoc")
		$Script:doc.Application.Selection.TypeParagraph() 
	} 	 catch {
		Write-Warning "Could not add the Table Error:$($_.exception.message)"
	}
	
}

#EndRegion Functions


#Region Variables

$WordNamestoShow = @()

$ErrorActionPreference = "Stop"
#EndRegion Variables 

$PowerShell30 = ($PSVersionTable.PSVersion.major -ge 3)
$VerbosePreference = 'Continue'

$scriptRoot = Split-Path -Parent $MyInvocation.MyCommand.Definition
$PSScriptRoot = $scriptRoot
$PathInputCSV = $PSScriptRoot
$datalocation = "$PSScriptRoot\data\"
write-verbose $PathInputCSV
dir "$($PathInputCSV)\InstanceName.csv" -Recurse | ForEach-Object {

	Write-Verbose "Generating the word documment. Please wait..." 
	$script:word=$null
	$script:doc=$null
	$Directory = $_.directoryName
	
	$Split = $_.name -split "_"
	If ($Split[2]) {
		$FullPath = "$($Directory)\$($Split[0])_$($Split[1])"
		$WordFileName ="$(Get-Date -Format yyyyMMddhhmm)_ADS_Overview_Report.docx" 
	} else {
		$FullPath = "$($Directory)\$($Split[0])"
		$WordFileName ="$(Get-Date -Format yyyyMMddhhmm)_ADS_Overview_Report.docx"
	}	
	
	$WordFileNameToSave = "$($PathInputCSV)\$WordFileName"

	
	$WordDocument = Start-MSWordDocumentSession  -verbose:$false #-templatepath "C:\laerte\ST\templatedoc.dotx"
	if (($WordDocument.ExitCode) -eq 1 ) {
		Write-Warning -Message "Could not create the word document. Error : $($WordDocument.Message)"
		Write-Error $WordDocument.Message
		Return
	}
	
	
	Add-MSWordText -Size 28 -text $cReporttitle
	Add-MSWordBreak
	Add-MSWordText -Size 11 -text "Inhaltsverzeichnis" -Color  wdColorBlue
	Add-MSwordToc
	Add-MSWordBreak

	$Object  = Import-Csv "$($FullPath)"

	<# if ($Object) {
		
		Add-MSWordParagraph  -text "Initial Review Report - INSTANCE NAME: $($Object.InstanceName)" -Style wdStyleHeading1
	} #>

	Add-MSWordParagraph  -text "Server Overview" -Style wdStyleHeading1

	#Region AD Info Information
		Write-Verbose -Message "Writing DC Server Information"


		Try {
			$Object = Import-Csv "$($datalocation)AD Server.csv"
			if($Object) {
				Add-MSWordParagraph -text "AD Information"  -Style wdStyleHeading2
				Add-MSWordTable -Object $Object
			}
		} Catch {
			Write-Warning "Could not create the AD Information Section : Error $($_.Exception.message)"
		}

	#EndRegion AD Info Information
	
	#Region Forest Information
		Write-Verbose -Message "Writing Forest Information"


		Try {
			$Object = Import-Csv "$($datalocation)Forest.csv"
			if($Object) {
				Add-MSWordParagraph -text "Forest Information"  -Style wdStyleHeading2
				Add-MSWordTable -Object $Object
			}
		} Catch {
			Write-Warning "Could not create the Forest Information Section : Error $($_.Exception.message)"
		}

	#EndRegion Forest Information
	
	#Region OS Information
		Write-Verbose -Message "Writing OS Information"


		Try {
			$Object = Import-Csv "$($datalocation)OS Information.csv"
			if($Object) {
				Add-MSWordParagraph -text "OS Information"  -Style wdStyleHeading2
				Add-MSWordTable -Object $Object
			}
		} Catch {
			Write-Warning "Could not create the OS Information Section : Error $($_.Exception.message)"
		}

	#EndRegion OS Information
	
	#Region FSMO Information
		Write-Verbose -Message "Writing FSMO Information"


		Try {
			$Object = Import-Csv "$($datalocation)FSMO.csv"
			if($Object) {
				Add-MSWordParagraph -text "FSMO Information"  -Style wdStyleHeading2
				Add-MSWordTable -Object $Object
			}
		} Catch {
			Write-Warning "Could not create FSMO Section : Error $($_.Exception.message)"
		}

	#EndRegion OS Information

	#Region Server Information
		Write-Verbose -Message "Writing Server Serverinformation"


		Try {
			$Object = Import-Csv "$($datalocation)Server Information.csv"
			if($Object) {
				Add-MSWordParagraph -text "Server Configuration"  -Style wdStyleHeading2
				Add-MSWordTable -Object $Object
			}
		} Catch {
			Write-Warning "Could not create Server Configuration Section : Error $($_.Exception.message)"
		}

	#EndRegion Server Configuration

	#Region DNS Configuration
		Try {
	  
			Write-Verbose -Message "Writing DNS Configuration"
			$Object = Import-Csv "$($datalocation)Netzwerk Konfiguration.csv"
			IF($Object) {
				Add-MSWordParagraph  -text "Netzwerk Configuration "  -Style wdStyleHeading2
				Add-MSWordTable -Object $Object
			}
		} Catch {
			Write-Warning  "Could not create DNS Configuration Section : Error $($_.Exception.message)"
		}


	#EndRegion DNS Configuration

	#Region DNS Zones Configuration
		Try {
	  
			Write-Verbose -Message "Writing DNS Zones Informaton"
			$Object = Import-Csv "$($datalocation)DNSZones.csv"
			IF($Object) {
				Add-MSWordParagraph  -text "DNS Zones Overview"  -Style wdStyleHeading2
				Add-MSWordTable -Object $Object
			}
		} Catch {
			Write-Warning  "Could not create DNS Zones Configuration Section : Error $($_.Exception.message)"
		}


	#EndRegion DNS Zones Configuration
	
	#Region DHCP Server Information
<# 		Try {
	  
			Write-Verbose -Message "Writing DHCP Server Information"
			$Object = Import-Csv "$($datalocation)DHCP.csv"
			IF($Object) {
				Add-MSWordParagraph  -text "DHCP Server Overview"  -Style wdStyleHeading2
				Add-MSWordTable -Object $Object
			}
		} Catch {
			Write-Warning  "Could not create DHCP Server Information Section : Error $($_.Exception.message)"
		}
 #>
	#EndRegion DHCP Server Information
	
	#Region Admin Groups Information
		Try {
	  
			Write-Verbose -Message "Writing Admin Groups Information"
			#$text = get-content "$($datalocation)Admin Groups.txt"
			$Object = Import-Csv "$($datalocation)Admin Groups.csv"
			IF($Object) {
				Add-MSWordParagraph  -text "AD Admin Groups Overview"  -Style wdStyleHeading2
				Add-MSWordText -Size 11 -text (get-content "$($datalocation)Admin Groups.txt")
				Add-MSWordText -Size 11 -text ((get-content "$($datalocation)Count Admin Groups.txt") + " priveledged Groups in AD")
				Add-MSWordTable -Object $Object
			}
		} Catch {
			Write-Warning  "Could not create Admin Groups Information Section : Error $($_.Exception.message)"
		}

	#EndRegion Admin Groups Information
	
	#Region NTP Information
		Try {
			Write-Verbose -Message "Writing DC NTP Information"
			Add-MSWordParagraph  -text "DC NTP Settings"  -Style wdStyleHeading2
			$ntps = get-childitem $datalocation -filter 'ntp*.txt'
			foreach ($ntp in $ntps) {
				$text = Get-Content $datalocation$ntp -Encoding UTF8 -Raw
				$tillename = ($ntp.basename).split()[-1]
					IF($text) {
					Add-MSWordParagraph  -text $tillename  -Style wdStyleHeading3
					Add-MSWordText -Size 11 -text $text
				}
			}
		} Catch {
			Write-Warning  "Could not create NTP Information Section : Error $($_.Exception.message)"
		}

	#EndRegion NTP Information

	Write-Verbose -Message "Updating TOC"
	Update-MSWordTOC

	Write-Verbose -Message "Saving the document at $($WordFileNameToSave)"
	$save = Remove-MSWordDocumentSession -ParamWordfileName $WordFileNameToSave 
	if($Save.ExitCode -eq 0) {
		Write-Verbose -Message "**************************************************************************"	
		Write-Verbose -Message "**************************************************************************"	

		Write-Verbose -Message "Document $($WordFileName) saved at $($WordFileNameToSave )"	

		Write-Verbose -Message "**************************************************************************"	
		Write-Verbose -Message "**************************************************************************"	
		$WordNamestoShow += $WordFileNameToSave
		
	} else {
		Write-Warning "An Error ocurred trying to save the document $($WordFileName). Please Run again Error : $($Save.Message)"
	}
	
}
Write-Verbose "Script Finished. You can close the PowerShell Session"
Write-Verbose "Word Documents saved at :"
$WordNamestoShow | 
ForEach-Object {
	Write-Verbose $_
}
#Start-Sleep -Seconds 100000