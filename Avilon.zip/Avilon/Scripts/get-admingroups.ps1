$Groups = Get-ADGroup -LDAPFilter "(admincount=1)" | select-object Name, GroupCategory, GroupScope

foreach ($group in $Groups) {
	$outputadgroup = @()
	$objadgroup  = New-Object -TypeName PSObject
	$objadgroup | Add-Member -MemberType NoteProperty -Name "Group Name" -Value $group.name
	$objadgroup | Add-Member -MemberType NoteProperty -Name "Members" -Value (Get-ADGroupMember -Identity $group.name).count
	$objadgroup | Add-Member -MemberType NoteProperty -Name "Category" -Value $group.groupcategory
	$objadgroup | Add-Member -MemberType NoteProperty -Name "Scope" -Value $group.groupscope
	$outputadgroup += $objadgroup
	$outputadgroup | Export-CSV .\data\"$($group.name).csv" -notypeinformation
}
