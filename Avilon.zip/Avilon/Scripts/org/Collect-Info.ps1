﻿$outputdc = @()
$outputsrv = @()
$outputdns = @()
$outputos = @()

#$ForestObj = (Get-ADForest).Domains
#$AllDcs = $Domains | % { Get-ADDomainController -Filter * }
$AllDcs = (Get-ADForest).Domains | % { Get-ADDomainController -Discover -DomainName  $_ } | % { Get-ADDomainController -server $_.Name -filter * } #| Select Name, Domain, Forest, IPv4Address, Site, OperationMasterRoles
#foreach($Domain in $ForestObj) {    
#	$AllDcs = Get-ADDomainController -Filter * #-Server $Domain | select Domain,Hostname,Ipv4address,isglobalcatalog,site,forest,operatingsystem
#}

foreach ($ComputerName in ($AllDcs.Hostname)) {
##This section queries and collects the relevant information into variables
			
			$dcinfo = Get-ADDomainController -server $ComputerName | select-object -property *
			$netinfo = Get-WmiObject Win32_NetworkAdapterConfiguration -ComputerName $ComputerName  | ? {$_.IPEnabled}
			$osinfo = Get-CimInstance -ClassName win32_operatingsystem -ComputerName $ComputerName  | Select-Object -Property *
			
			if ($osinfo.version -like "*6.3*") {
				$osversion = "2012 R2"
			}
			elseif ($osinfo.version -like "*6.2*") {
				$osversion = "2012"
			}
			elseif ($osinfo.version -like "*10.0*") {
				$osversion = "2019"
			}
			elseif ($osinfo.version -like "*6.1*") {
				$osversion = "2008 R2"
			}
			elseif ($osinfo.version -like "*6.0*") {
				$osversion = "2008"
			}
			
			if ($osinfo.caption -like "*Standard*") {
				$osedition = "Standard"
			}
			if ($osinfo.caption -like "*Enterprise*") {
				$osedition = "Enterprise"
			}
			if ($osinfo.caption -like "*Datacenter*") {
				$osedition = "Datacenter"
			}
			$OpsMasterRole = $dcinfo.OperationMasterRoles -join ','
			$DefaultGateway = $netinfo.DefaultIPGateway -join ','
			$DNSServers = $netinfo.DNSServerSearchOrder -join ','
			$IPAddinfo = ($netinfo | Where-Object{$_.ipaddress -notlike $null, "192", "169"}).IPaddress | Select-Object -First 1			           
					   
            $basicinfo = Get-WmiObject Win32_ComputerSystem -ComputerName $ComputerName -ErrorAction STOP | Select-Object Name,DnsHostName,Domain
            $memory = Get-WmiObject -Class Win32_PhysicalMemory -ComputerName $ComputerName |Measure-Object -Property capacity -Sum
            $hardwareinfo = Get-WmiObject -Class Win32_ComputerSystem -ComputerName $ComputerName -Property Manufacturer, Model
            $processor = Get-WmiObject –class Win32_processor -ComputerName $ComputerName | Select-Object systemname,Name,DeviceID,NumberOfCores,NumberOfLogicalProcessors, Addresswidth
            $serial = Get-WmiObject -Class Win32_Bios -ComputerName $ComputerName 
			$TotalAvailMemory = ([math]::round(($memory.Sum / 1GB),2))

# DC Server Region
			$objdc = new-object -type psobject
			$objdc | Add-Member -MemberType NoteProperty -Name ServerName -Value $basicinfo.DnsHostName
			$objdc | Add-Member -MemberType NoteProperty -Name Domain -Value $dcinfo.domain
			$objdc | Add-Member -MemberType NoteProperty -Name Forest -Value $dcinfo.forest
			$objdc | Add-Member -MemberType NoteProperty -Name Site -Value $dcinfo.Site
			$objdc | Add-Member -MemberType NoteProperty -Name FSMO -Value $opsMasterRole
			$objdc | Add-Member -MemberType NoteProperty -Name "GC" -Value $dcinfo.IsGlobalCatalog
			$objdc
			$outputdc += $objdc
			
# Server Region
			$objsrv = new-object -type psobject #-Property @{
            $objsrv | Add-Member -MemberType NoteProperty -Name Servername -Value $basicinfo.DnsHostName
			$objsrv | Add-Member -MemberType NoteProperty -Name "Memory (GB)" -Value ("{0:N2}" -f $TotalAvailMemory)
            $objsrv | Add-Member -MemberType NoteProperty -Name CPU -Value $processor.NumberOfLogicalProcessors
			$objsrv | Add-Member -MemberType NoteProperty -Name Manufacturer -Value $hardwareinfo.manufacturer
			$objsrv			 
			$outputsrv += $objsrv
			
# DNS Region
			$objdns = new-object -type psobject #-Property @{
            $objdns | Add-Member -MemberType NoteProperty -Name Servername -Value $basicinfo.DnsHostName
			$objdns | Add-Member -MemberType NoteProperty -Name IP -Value $ipaddinfo
			$objdns | Add-Member -MemberType NoteProperty -Name SN -Value $netinfo.IPSubnet[0]
			$objdns | Add-Member -MemberType NoteProperty -Name GW -Value $DefaultGateway
			$objdns | Add-Member -MemberType NoteProperty -Name "DNS Server" -Value $DNSServers
			$objdns | Add-Member -MemberType NoteProperty -Name "WINS 1" -Value $netinfo.WINSPrimaryServer
			$objdns | Add-Member -MemberType NoteProperty -Name "WINS 2" -Value $netinfo.WINSSecondaryserver
			$objdns | Add-Member -MemberType NoteProperty -Name "DHCP Enabled" -Value $netinfo.DHCPEnabled
			$objdns			 
			$outputdns += $objdns
			
# OS Region
			$objos = new-object -type psobject #-Property @{
            $objos | Add-Member -MemberType NoteProperty -Name Servername -Value $osinfo.PSComputerName
			$objos | Add-Member -MemberType NoteProperty -Name Sprache -Value $osinfo.OSLanguage
			$objos | Add-Member -MemberType NoteProperty -Name Version -Value $osversion
			$objos | Add-Member -MemberType NoteProperty -Name Edition -Value $osedition
			$objos | Add-Member -MemberType NoteProperty -Name Uptime -Value $osinfo.LastBootuptime
			$objos			 
			$outputos += $objos

}

$outputsrv | Export-CSV .\data\"Server Information.csv" -notypeinformation
$outputdns | Export-CSV .\data\"Netzwerk Konfiguration.csv" -notypeinformation
$outputos  | Export-CSV .\data\"OS Information.csv" -notypeinformation
$outputdc  | Export-CSV .\data\"AD Server.csv" -notypeinformation

			#$obj | Add-Member -MemberType NoteProperty -Name ADDomain -Value $basicinfo.domain
			#Last Boot
			#Installed on
			#Pending reboot
			#NTP
##This command will take the information collected above and export it to a CSV within the C:\temp folder
#$output | Select-Object Servername,ADDomain,IPAddress,PageFile, PageFileLocation, "Memory (GB)", Manufacturer, CPU | Export-CSV c:\temp\OSinfo.csv
#$output | Export-CSV c:\temp\OSinfo.csv -notypeinformation
    

